
package model;

public class Login {
    private int login;
    private String senha;
    
    public void setLogin(int login){
        this.login=login;
    };
    public int getLogin(){
        return login;
    };
    public void setSenha(String senha){
        this.senha=senha;
    };
    public String getSenha(){
        return senha;
    };
}
