package com.mycompany.banco;
import model.Usuario;
import model.Endereco;
import controller.UsuarioControle;
import view.ViewCriarUsuario;
import view.ViewTransferir;
import view.ViewCartao;
import view.Principal;

public class Banco {

    public static void main(String[] args) {
        Principal tela = new Principal();
        tela.setVisible(true);
    }
}
