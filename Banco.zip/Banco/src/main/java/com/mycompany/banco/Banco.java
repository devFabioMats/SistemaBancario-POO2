package com.mycompany.banco;
import model.Usuario;
import model.Endereco;
import controller.UsuarioControle;
import view.ViewUsuario;

public class Banco {

    public static void main(String[] args) {
        ViewUsuario tela = new ViewUsuario();
        tela.setVisible(true);
    }
}
