package model;

public class Gerente {
    int codigoGerente;
    
    public int getCodigo(){
        return codigoGerente;
    }
    public void setCodigo(int codigoGerente){
        this.codigoGerente = codigoGerente;
    }
}
