package model;
import java.util.Date;

public class CartaoVirtual {
    private long numeroCartao;
    private int cvv;
    private Date expiracao;
    private int limite;
    
    public long getCartao(){
        return numeroCartao;
    }
    public void setCartao(long numeroCartao){
        this.numeroCartao=numeroCartao;
    }
    public int getCvv(){
        return cvv;
    }
    public void setCvv(int cvv){
        this.cvv=cvv;
    }
    public Date getExp(){
        return expiracao;
    }
    public void setExp(Date expiracao){
        this.expiracao=expiracao;
    }
    public int getLimite(){
        return limite;
    }
    public void setLimite(int limite){
        this.limite=limite;
    }
}
