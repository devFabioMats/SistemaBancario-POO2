package controller;
import java.util.Date;
import model.CartaoVirtual;
import java.util.Random;

public class CartaoControle {
    long numeroCartao;
    int cvv;
    Date expiracao;
    int limite;
    
    //  public CartaoCrtl(){
    //      
    // }
    
    public void gerarCartão(CartaoVirtual cartao) {
        //String sql = "";
        System.out.println("Cartão gerado com sucesso");
    }
}
